package com.VarsityCollege.st10316986

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnaddition = findViewById<Button>(R.id.btnaddition)
        val btnsubtraction = findViewById<Button>(R.id.btnsubtraction)
        val btnmultiplication = findViewById<Button>(R.id.btnmultiplication)
        val btndivision = findViewById<Button>(R.id.btndivision)
        val edtnum1 = findViewById<EditText>(R.id.edtnum1)
        val edtnum2 = findViewById<EditText>(R.id.edtnum2)
        val edtanswer = findViewById<TextView>(R.id.edtanswer)


        btnaddition.setOnClickListener {
            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() + num2.toInt()
            edtanswer.text =  num1.toString() + " + " + num2.toString() + (" = ") + answer.toString()

        }
        btnsubtraction.setOnClickListener{
            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() - num2.toInt()
            edtanswer.text =  num1.toString() + " - " + num2.toString() + (" = ") + answer.toString()
        }
        btnmultiplication.setOnClickListener{

            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() * num2.toInt()
            edtanswer.text =  num1.toString() + " x " + num2.toString() + (" = ") + answer.toString()
        }
        btndivision.setOnClickListener {
            val num1 = edtnum1.text.toString()
            val num2 = edtnum2.text.toString()
            val answer = num1.toInt() / num2.toInt()
            edtanswer.text =  num1.toString() + " / " + num2.toString() + (" = ") + answer.toString()

        }
    }
}

//reference list
// www.w3schools.com. (n.d.). Kotlin Tutorial. [online] Available at: https://www.w3schools.com/kotlin/index.php.